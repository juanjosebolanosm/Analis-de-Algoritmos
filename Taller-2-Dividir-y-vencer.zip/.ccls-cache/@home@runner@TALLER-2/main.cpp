#include <iostream>
#include <string.h>
using namespace std;


int binario[1000];
int binarioInvertido[1000];
int poss=0;

void pasaraBinarioDividirVencer(int inicio, int fin){

   if (inicio == fin){
     binarioInvertido[poss]=binario[inicio];
     poss++;
     return;
   }

  int mitad =  (inicio + fin)/2;
 
   pasaraBinarioDividirVencer(mitad+1,  fin);
   pasaraBinarioDividirVencer(inicio, mitad);

}



int main() {


  int numero = 120;
  int i=0;

  while (numero != 0){
        if(numero % 2 == 0){
          binarioInvertido[i] = 0;
        }else{
          binarioInvertido[i] = 1;
        }     
        numero /= 2;
        i++;
  }

  int aux=0;
  for(int j = i; j>=0; j--){
        binario[aux]= binarioInvertido[j-1]; 
        aux++;
  }
  
   pasaraBinarioDividirVencer(0,i-1);


   int caracterActual;
   int multiplicador = 1;
  
    for (int j = i; j >= 0; j--) {
      caracterActual = binarioInvertido[j-1];
        if (caracterActual == 1) {
          numero += multiplicador;
        }
      multiplicador = multiplicador * 2;
    }
  cout<<"numero Deciamal: "<< numero<<endl;
  


  
  return 0;
  
}